"""Smaller 32x16 student retaining the full semantic visible-state codec."""
from torch import nn
from .model_v3 import SemanticTokenPolicyValue, STATE_WIDTH, ACTION_WIDTH


class MicroSemanticPolicyValue(SemanticTokenPolicyValue):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.policy = nn.Sequential(nn.Linear(STATE_WIDTH + ACTION_WIDTH, 32), nn.ReLU(),
                                    nn.Linear(32, 16), nn.ReLU(), nn.Linear(16, 1))
        self.value = nn.Sequential(nn.Linear(STATE_WIDTH, 32), nn.ReLU(),
                                   nn.Linear(32, 16), nn.ReLU(), nn.Linear(16, 6))
        for net in (self.policy, self.value):
            nn.init.zeros_(net[-1].weight)
            nn.init.zeros_(net[-1].bias)
