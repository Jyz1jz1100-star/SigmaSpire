"""Public token counts. Identity metadata is never read as a feature."""
from collections import defaultdict
import numpy as np
from neural_features_v8 import state_features, action_features

PILES=('hand','draw','discard','exhaust','masterDeck')


def tokens(state):
    result=defaultdict(set)
    for pile in PILES:
        for c in state.get(pile,[]):result['card'].add(c['id'])
    for r in state['relics']:
        if not r['melted']:result['relic'].add(r['id'])
    for p in state['potions']:
        if p['id']:result['potion'].add(p['id'])
    for e in state['enemies']:
        if e['id']:result['enemy'].add(e['id'])
    for p in state['powers']:
        team='shared' if p['owner'] is None else 'player' if p['owner']==state.get('playerCombatId',0) else 'enemy'
        result['power'].add(team+':'+p['id'])
    return result


class Codec:
    def __init__(self,vocabulary):
        self.vocabulary=vocabulary
        self.index={k:{token:i for i,token in enumerate(v)} for k,v in vocabulary.items()}

    def put(self,values,table,token,amount=1):
        if token:values[self.index[table].get(token,0)]+=amount

    def state(self,state):
        cards=np.zeros((5,len(self.index['card'])),np.float32);upgrades=cards.copy()
        for i,pile in enumerate(PILES):
            for c in state.get(pile,[]):
                self.put(cards[i],'card',c['id'],.1)
                self.put(upgrades[i],'card',c['id'],max(0,c['upgrade'])/10)
        out=dict(cards=cards,upgrades=upgrades,basic=np.asarray(state_features(state),np.float32))
        for k in ('relic','potion','enemy','power'):out[k]=np.zeros(len(self.index[k]),np.float32)
        for r in state['relics']:
            if not r['melted']:self.put(out['relic'],'relic',r['id'],.1)
        for p in state['potions']:self.put(out['potion'],'potion',p['id'],.25)
        for e in state['enemies']:
            if e['hp']>0:self.put(out['enemy'],'enemy',e['id'],.2)
        for p in state['powers']:
            team='shared' if p['owner'] is None else 'player' if p['owner']==state.get('playerCombatId',0) else 'enemy'
            self.put(out['power'],'power',team+':'+p['id'],p['amount']/10)
        master=state.get('masterDeck',[])
        out['scalars']=np.asarray([float('masterDeck' in state),len(master)/30,sum(max(0,c['upgrade']) for c in master)/10,sum(bool(p['id']) for p in state['potions'])/4],np.float32)
        return out

    def action(self,action,state):
        out=dict(basic=np.asarray(action_features(action,state),np.float32))
        for k in ('card','upgrade','choice','choiceUpgrade'):out[k]=np.zeros(len(self.index['card']),np.float32)
        out['potion']=np.zeros(len(self.index['potion']),np.float32)
        out['enemy']=np.zeros(len(self.index['enemy']),np.float32)
        if action['kind']=='PlayCard':
            self.put(out['card'],'card',action['cardId'])
            self.put(out['upgrade'],'card',action['cardId'],max(0,action['cardUpgradeLevel']))
        if action['kind']=='UsePotion':self.put(out['potion'],'potion',action['potionId'])
        choices=([action['choice']] if action.get('choice') else [])+(action.get('nestedChoices') or [])+(action.get('turnStartChoices') or [])
        for choice in choices:
            for card in choice['cards']:
                self.put(out['choice'],'card',card['cardId'],.1)
                self.put(out['choiceUpgrade'],'card',card['cardId'],max(0,card.get('upgradeLevel',0))/10)
        target=next((e for e in state['enemies'] if e.get('combatId')==action.get('targetCombatId') and action.get('targetCombatId') is not None),None)
        if target:self.put(out['enemy'],'enemy',target['id'])
        return out
