"""Distill semantic policy/value into48x32 residuals for bounded search latency."""
from torch import nn
from .model_v3 import SemanticTokenPolicyValue,STATE_WIDTH,ACTION_WIDTH


class CompactSemanticPolicyValue(SemanticTokenPolicyValue):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.policy=nn.Sequential(nn.Linear(STATE_WIDTH+ACTION_WIDTH,48),nn.ReLU(),nn.Linear(48,32),nn.ReLU(),nn.Linear(32,1))
        self.value=nn.Sequential(nn.Linear(STATE_WIDTH,48),nn.ReLU(),nn.Linear(48,32),nn.ReLU(),nn.Linear(32,6))
        for net in (self.policy,self.value):nn.init.zeros_(net[-1].weight);nn.init.zeros_(net[-1].bias)
