"""Semantic set encoder: learn identities while sharing public card mechanics."""
import torch
from torch import nn
from .model_v2 import StagedTokenPolicyValue

STATE_WIDTH,ACTION_WIDTH=807,218


class SemanticTokenPolicyValue(StagedTokenPolicyValue):
    def __init__(self,baseline,vocabulary,mechanics,dropout=.2):
        super().__init__(baseline,vocabulary,dropout)
        self.mechanics=mechanics
        self.policy=nn.Sequential(nn.Linear(STATE_WIDTH+ACTION_WIDTH,128),nn.ReLU(),nn.Linear(128,64),nn.ReLU(),nn.Linear(64,1))
        self.value=nn.Sequential(nn.Linear(STATE_WIDTH,128),nn.ReLU(),nn.Linear(128,64),nn.ReLU(),nn.Linear(64,6))
        for net in (self.policy,self.value):nn.init.zeros_(net[-1].weight);nn.init.zeros_(net[-1].bias)

    def state_features(self,state):
        return torch.cat([super().state_features(state),state['mechanics'],state['context']],-1)

    def action_features(self,action):
        return torch.cat([super().action_features(action),action['mechanics']],-1)

    def forward_policy(self,state,action):
        sf=self.state_features(state);af=self.action_features(action)
        if af.ndim==sf.ndim+1:sf=sf.unsqueeze(-2).expand(*af.shape[:-1],STATE_WIDTH)
        base=self.base_policy(torch.cat([sf[...,:256],af[...,:56]],-1)).squeeze(-1)
        residual=self.policy(self.dropout(torch.cat([sf,af],-1))).squeeze(-1)
        return (base+4*torch.tanh(residual/4))/self.policy_temperature

    def export(self,*args,**kwargs):
        out=super().export(*args,**kwargs)
        out['featureSchema']='visible-r48-semantic-policy-value-v2'
        out['r48Tokens'].update(stateWidth=STATE_WIDTH,actionWidth=ACTION_WIDTH,cardMechanics=self.mechanics,usePublicContext=True)
        return out
