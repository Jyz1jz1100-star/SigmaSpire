"""Semantic card roles/current variables, including unseen card identities."""
import numpy as np
from .codec import Codec as TokenCodec,tokens,PILES
from card_mechanics_r6 import action_mechanics
from public_context_r6 import context_features


class Codec(TokenCodec):
    def __init__(self,vocabulary,mechanics):
        super().__init__(vocabulary);self.mechanics=mechanics

    def state(self,state):
        result=super().state(state);features=[]
        for pile in PILES:
            plain=np.zeros(26,np.float32);upgraded=plain.copy()
            for card in state.get(pile,[]):
                roles=self.mechanics.get(card['id'])
                if roles is None:continue
                vector=np.asarray([1.]+roles,np.float32)/10
                plain+=vector;upgraded+=vector*max(0,card['upgrade'])
            features.extend(np.clip(plain,-4,4));features.extend(np.clip(upgraded,-4,4))
        result['mechanics']=np.asarray(features,np.float32)
        result['context']=np.asarray(context_features(state),np.float32)
        return result

    def action(self,action,state):
        result=super().action(action,state)
        result['mechanics']=np.asarray(action_mechanics(action,self.mechanics),np.float32)
        return result
