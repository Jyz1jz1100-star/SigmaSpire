"""Staged actor/critic learning with bounded resource corrections/calibration."""
import torch
from .model import TokenPolicyValue


class StagedTokenPolicyValue(TokenPolicyValue):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.policy_temperature=1.

    def forward_policy(self,state,action):
        return super().forward_policy(state,action)/self.policy_temperature

    def forward_value(self,state):
        # Fixed actor representation during critic fitting prevents cross-task drift.
        sf=self.state_features(state).detach()
        residual=self.value(self.dropout(sf));base=self.base_value(sf[...,:256])
        bounds=torch.tensor([1.,.25,.15],device=sf.device)
        return torch.cat([base+bounds*torch.tanh(residual[...,:3]/bounds),residual[...,3:]],-1)

    def export(self,*args,**kwargs):
        out=super().export(*args,**kwargs)
        out['r48Tokens'].update(valueHeadResidualBounds=[1.,.25,.15],policyTemperature=self.policy_temperature)
        return out
