"""Learned unordered identity/upgrade bags plus a bounded policy/value residual.

The first linear lookup of each token is a learned embedding, not a seed hash.
Native inference exports these same lookup tables and ordinary dense layers.
"""
import torch
from torch import nn

SCHEMA = 'visible-r48-token-policy-value-v1'
STATE_WIDTH, ACTION_WIDTH = 476, 128
TABLE_DIMS = {'card':16, 'upgrade':16, 'relic':16, 'potion':8, 'enemy':16, 'power':16}


def dense(layers):
    result=[]
    for i, layer in enumerate(layers):
        part=nn.Linear(len(layer['weight'][0]),len(layer['bias']))
        with torch.no_grad():part.weight.copy_(torch.tensor(layer['weight']));part.bias.copy_(torch.tensor(layer['bias']))
        result.append(part)
        if i+1<len(layers):result.append(nn.ReLU())
    return nn.Sequential(*result)


def export_layers(network):
    return [dict(weight=x.weight.detach().cpu().tolist(),bias=x.bias.detach().cpu().tolist()) for x in network if isinstance(x,nn.Linear)]


class TokenPolicyValue(nn.Module):
    def __init__(self, baseline, vocabulary, dropout=0.10):
        super().__init__()
        self.vocabulary=vocabulary
        self.tables=nn.ParameterDict({k:nn.Parameter(torch.randn(len(vocabulary['card' if k=='upgrade' else k]),d)*0.03) for k,d in TABLE_DIMS.items()})
        with torch.no_grad():
            for table in self.tables.values():table[0].zero_()
        self.base_policy=dense(baseline['policyLayers'])
        self.base_value=dense(baseline['valueLayers'])
        for p in list(self.base_policy.parameters())+list(self.base_value.parameters()):p.requires_grad_(False)
        self.policy=nn.Sequential(nn.Linear(STATE_WIDTH+ACTION_WIDTH,128),nn.ReLU(),nn.Linear(128,64),nn.ReLU(),nn.Linear(64,1))
        self.value=nn.Sequential(nn.Linear(STATE_WIDTH,128),nn.ReLU(),nn.Linear(128,64),nn.ReLU(),nn.Linear(64,6))
        self.dropout=nn.Dropout(dropout)
        nn.init.zeros_(self.policy[-1].weight);nn.init.zeros_(self.policy[-1].bias)
        nn.init.zeros_(self.value[-1].weight);nn.init.zeros_(self.value[-1].bias)

    def state_features(self, state):
        c,u,basic,scalars=state['cards'],state['upgrades'],state['basic'],state['scalars']
        parts=[basic,(c@self.tables['card']).flatten(-2),(u@self.tables['upgrade']).flatten(-2)]
        parts += [state[k]@self.tables[k] for k in ('relic','potion','enemy','power')]
        parts.append(scalars)
        result=torch.cat(parts,dim=-1)
        assert result.shape[-1]==STATE_WIDTH
        return result

    def action_features(self, action):
        parts=[action['basic'],action['card']@self.tables['card'],action['upgrade']@self.tables['upgrade'],
            action['potion']@self.tables['potion'],action['choice']@self.tables['card']+action['choiceUpgrade']@self.tables['upgrade'],action['enemy']@self.tables['enemy']]
        result=torch.cat(parts,dim=-1)
        assert result.shape[-1]==ACTION_WIDTH
        return result

    def forward_policy(self, state, action):
        sf=self.state_features(state);af=self.action_features(action)
        if af.ndim==sf.ndim+1:sf=sf.unsqueeze(-2).expand(*af.shape[:-1],STATE_WIDTH)
        original=torch.cat([sf[...,:256],af[...,:56]],dim=-1)
        residual=self.policy(self.dropout(torch.cat([sf,af],dim=-1))).squeeze(-1)
        return self.base_policy(original).squeeze(-1)+4*torch.tanh(residual/4)

    def forward_value(self,state):
        sf=self.state_features(state)
        residual=self.value(self.dropout(sf))
        base=self.base_value(sf[...,:256])
        return torch.cat([base+torch.tanh(residual[...,:3]),residual[...,3:]],dim=-1)

    def export(self,baseline,model_id):
        result=dict(baseline,modelId=model_id,featureSchema=SCHEMA)
        result['r48Tokens']=dict(vocabulary=self.vocabulary,weights={k:v.detach().cpu().tolist() for k,v in self.tables.items()},
            policyLayers=export_layers(self.policy),valueLayers=export_layers(self.value),stateWidth=STATE_WIDTH,actionWidth=ACTION_WIDTH,
            policyResidualBound=4,valueResidualBound=1,valueHeadOrder=['complete_survival_logit','normalized_hp_cost','normalized_potion_cost','terminal_enemy_hp_fraction','remaining_turns_over20','native_policy_run_win_logit'])
        return result


def take(tensors, indices):return {k:v[indices] for k,v in tensors.items()}
