"""Public, order-invariant whole-run features; no seed, RNG or future stock.

Reuse C9's learned item embeddings and card-mechanic table. The set sum follows
Deep Sets (https://arxiv.org/abs/1703.06114); this codec runs without Torch in UI.
Mechanism tags describe pinned game hooks, never a purchase preference or score.
"""
from collections import Counter
import hashlib
import math

from .public_map import public_options
from .market import market_features

SCHEMA = "r51-public-joint-value-v1"
PHASES = ("map", "shop", "event", "rest_site", "card_reward", "combat", "game_over", "card_select", "treasure")
KINDS = ("Shop", "Monster", "Elite", "RestSite", "Treasure", "Unknown", "Boss")
MECHANISM_NAMES = ("energy_retention", "hand_retention", "first_turn_hand_retention",
                   "periodic_energy", "delayed_energy", "elite_opening_energy", "capped_block_retention",
                   "unclassified_relics")
# Public encounter identities from the existing pinned generated-scenario
# catalogue. The Kin and Kaiser Crab are not guessed to be one enemy identity.
PUBLIC_BOSSES = ("CEREMONIAL_BEAST_BOSS", "THE_KIN_BOSS", "VANTOM_BOSS", "WATERFALL_GIANT_BOSS",
                 "LAGAVULIN_MATRIARCH_BOSS", "SOUL_FYSH_BOSS", "KAISER_CRAB_BOSS",
                 "KNOWLEDGE_DEMON_BOSS", "THE_INSATIABLE_BOSS", "AEONGLASS_BOSS", "QUEEN_BOSS", "TEST_SUBJECT_BOSS")
# Verified against the installed game's decompiled classes in the observation
# evidence directory. Calipers is deliberately absent: that type was not found.
RELIC_MECHANISMS = {"ICE_CREAM": "energy_retention", "RUNIC_PYRAMID": "hand_retention",
                    "RINGING_TRIANGLE": "first_turn_hand_retention",
                    "HAPPY_FLOWER": "periodic_energy", "PAELS_FLESH": "delayed_energy",
                    "BOOMING_CONCH": "elite_opening_energy", "STURDY_CLAMP": "capped_block_retention"}


def identity(value):
    if isinstance(value, str):
        return value.rsplit(".", 1)[-1]
    return str((value or {}).get("id") or "").rsplit(".", 1)[-1]


def upgrade(card):
    return max(0, int(card.get("upgrade_levels", card.get("upgrade", int(bool(card.get("is_upgraded")))))))


def bounded(value, scale=1.):
    value = float(value) / scale
    if not math.isfinite(value):
        raise ValueError("Nonfinite public value")
    return max(-8., min(8., value))


class PublicCodec:
    def __init__(self, tokens):
        self.tokens = tokens
        self.indices = {k: {name: i for i, name in enumerate(v)}
                        for k, v in tokens["vocabulary"].items()}
        self.names = None

    def _bag(self, table, entries):
        vocab = self.indices["card" if table == "upgrade" else table]
        weights = self.tokens["weights"][table]
        result = [0.] * len(weights[0])
        for name, amount in entries:
            if not name:
                continue
            for i, value in enumerate(weights[vocab.get(name, 0)]):
                result[i] += value * amount
        return result

    def encode(self, state, *, board=None, option_index=None, policy="candidate009", capability=None):
        """board must belong to the current act; the caller owns that provenance.

        option_index conditions a route candidate on its public suffix. None
        describes the currently available alternatives. No state field outside
        this explicit allowlist is inspected.
        """
        player, run = state.get("player", {}), state.get("run", {})
        deck, relics, potions = (player.get("deck", []), player.get("relics", []),
                                 player.get("potions", []))
        relics = [r for r in relics if not isinstance(r, dict) or not r.get("melted", False)]
        potions = [p for p in potions if identity(p)]
        values, names = [], []

        def add(name, value, scale=1.):
            names.append(name)
            values.append(bounded(value, scale))

        def vector(prefix, vector):
            for i, value in enumerate(vector):
                add(prefix + str(i), value)

        hp, maximum, gold = player.get("hp", 0), player.get("max_hp", 0), player.get("gold", 0)
        for key, value, scale in (("act", run.get("act", 0), 3), ("floor", run.get("floor", 0), 50),
                                  ("hp", hp, 100), ("max_hp", maximum, 100),
                                  ("hp_fraction", hp / max(1, maximum), 1),
                                  ("gold", gold, 500), ("deck_size", len(deck), 30),
                                  ("upgrades", sum(upgrade(c) for c in deck), 10),
                                  ("relic_count", len(relics), 20), ("potion_count", len(potions), 4),
                                  ("potion_slots", player.get("max_potion_slots", 0), 4)):
            add(key, value, scale)
        add("candidate009_policy", policy == "candidate009")
        add("other_policy", policy != "candidate009")
        for phase in PHASES:
            add("phase_" + phase, state.get("state_type") == phase)
        vector("deck_token_", self._bag("card", [(identity(c), .1) for c in deck]))
        vector("upgrade_token_", self._bag("upgrade", [(identity(c), upgrade(c) / 10) for c in deck]))
        vector("relic_token_", self._bag("relic", [(identity(r), .1) for r in relics]))
        vector("relic_counter_token_", self._bag("relic", [(identity(r), float(r["counter"]) / 10)
            for r in relics if isinstance(r, dict) and isinstance(r.get("counter"), (int, float))]))
        vector("potion_token_", self._bag("potion", [(identity(p), .25) for p in potions]))
        # Only the visible attachment ID/amount is used, never arbitrary saved
        # properties, hidden RNG or generated future effects. The compound ID
        # distinguishes enchanting Strike from enchanting a different card.
        attachments, attached_cards = [0.] * 16, [0.] * 16
        enchant_count = known_amounts = 0
        for card in deck:
            enchantment = (card.get("forecast_card") or {}).get("enchantment")
            if not isinstance(enchantment, dict) or not enchantment.get("id"):
                continue
            enchant_count += 1
            amount = enchantment.get("amount")
            known_amounts += isinstance(amount, (int, float))
            scale = float(amount) / 10 if isinstance(amount, (int, float)) else .1
            for token, destination in ((str(enchantment["id"]), attachments),
                                       (identity(card) + "|" + str(enchantment["id"]), attached_cards)):
                digest = hashlib.sha256(token.encode("utf-8")).digest()
                for i in range(16):
                    destination[i] += scale * (1 if digest[i] & 1 else -1)
        vector("visible_enchantment_", attachments)
        vector("enchanted_card_", attached_cards)
        add("enchanted_cards", enchant_count, 10)
        add("known_enchantment_amounts", known_amounts, 10)
        roles, upgraded_roles = [0.] * 26, [0.] * 26
        unknown_cards, costs = 0, []
        types = Counter()
        for card in deck:
            mechanics = self.tokens["cardMechanics"].get(identity(card))
            unknown_cards += mechanics is None
            if mechanics is not None:
                if len(mechanics) != 25:
                    raise ValueError("Card mechanic schema changed")
                for i, value in enumerate([1.] + mechanics):
                    roles[i] += value / 10
                    upgraded_roles[i] += value * upgrade(card) / 10
            try:
                cost = float(card.get("cost"))
                if cost >= 0 and math.isfinite(cost):
                    costs.append(cost)
            except (ValueError, TypeError):
                pass
            types[card.get("type")] += 1
        vector("deck_role_", roles)
        vector("upgraded_role_", upgraded_roles)
        add("unknown_card_mechanics", unknown_cards, 10)
        for kind in ("Attack", "Skill", "Power", "Curse", "Status"):
            add("deck_" + kind, types[kind], 10)
        add("known_cost_fraction", len(costs) / max(1, len(deck)))
        add("mean_known_cost", sum(costs) / max(1, len(costs)), 3)
        add("cost_two_or_more", sum(x >= 2 for x in costs), 10)
        mechanism_counts = Counter(RELIC_MECHANISMS.get(identity(r), "unclassified_relics") for r in relics)
        for name in MECHANISM_NAMES:
            add(name, mechanism_counts[name], 10 if name == "unclassified_relics" else 1)
        counters = [r.get("counter") for r in relics if isinstance(r, dict)]
        numeric_counters = [c for c in counters if isinstance(c, (float, int))]
        add("known_relic_counter_count", len(numeric_counters), 10)
        add("relic_counter_sum", sum(numeric_counters), 30)

        if board is None and state.get("state_type") == "map":
            board = state.get("map")
        report = public_options(board) if board is not None else dict(complete=False, options=[])
        options = report["options"]
        selected = next((x for x in options if x["index"] == option_index), None)
        if option_index is not None and selected is None:
            raise ValueError("Route option not publicly available")
        scope = [selected] if selected else options
        add("public_map_available", board is not None)
        add("public_map_complete", report["complete"])
        add("route_candidate", selected is not None)
        add("route_choice_count", len(options), 6)
        for key in ("minShops", "maxShops", "minFights", "maxFights", "minElites", "maxElites",
                    "minUnknown", "maxUnknown", "minRests", "maxRests"):
            add("suffix_" + key, min((x[key] for x in scope), default=0), 10)
        access = [x["firstShop"] for x in scope if x["firstShop"] is not None]
        add("public_shop_access", bool(access))
        for key in ("distance", "fights", "elites"):
            add("first_shop_" + key, min((x[key] for x in access), default=0), 10)
        rest_access = [x["firstRest"] for x in scope if x["firstRest"] is not None]
        add("public_rest_access", bool(rest_access))
        for key in ("distance", "fights", "elites"):
            add("first_rest_" + key, min((x[key] for x in rest_access), default=0), 10)
        all_shops = {tuple(c) for x in options for c in x["reachableShopCoordinates"]}
        scoped_shops = {tuple(c) for x in scope for c in x["reachableShopCoordinates"]}
        add("reachable_public_shops", len(scoped_shops), 6)
        add("forgone_public_shops", len(all_shops - scoped_shops), 6)
        # Conditional prices are a training-only distribution. Access remains
        # a separate public topology feature; there is no peek at future stock.
        for name, value in market_features(self.tokens.get("marketDistribution"), run.get("act"), gold).items():
            add("future_market_" + name, value)
        selected_kind = None
        if selected:
            selected_kind = next(n["type"] for n in board["nodes"]
                                 if [n["col"], n["row"]] == selected["coordinate"])
        for kind in KINDS:
            add("selected_node_" + kind, selected_kind == kind)
        bosses = (board or {}).get("bosses", [])
        if not bosses and (board or {}).get("boss"):
            bosses = [board["boss"]]
        # Share a known enemy token only for an exact shared ID stem. This is
        # an identity feature, not a claim about a multi-monster boss roster.
        stems = [identity(b).removesuffix("_BOSS") for b in bosses]
        vector("public_boss_token_", self._bag("enemy", [(stem, .2) for stem in stems if stem in self.indices["enemy"]]))
        boss_ids = {identity(b) for b in bosses}
        for boss in PUBLIC_BOSSES:
            add("public_boss_" + boss, boss in boss_ids)
        add("unclassified_public_boss", len(boss_ids - set(PUBLIC_BOSSES)))
        current_row = ((board or {}).get("current_position") or {}).get("row")
        if selected:
            current_row = selected["coordinate"][1]
        distances = [b["row"] - current_row for b in bosses
                     if isinstance(b.get("row"), int) and isinstance(current_row, int) and b["row"] >= current_row]
        add("public_boss_known", bool(bosses))
        add("distance_to_act_boss_known", bool(distances))
        add("distance_to_act_boss", min(distances, default=0), 16)
        # Visible shop inventory only. At any other phase even injected shop
        # contents are ignored. Unknown future stock never enters this vector.
        closed_shop = state.get("_r51_shop_closed") is True
        add("current_card_reward_opportunity_closed", state.get("_r51_card_reward_closed") is True)
        shop_known = state.get("state_type") == "shop" and not closed_shop
        shop = state.get("shop", {}) if shop_known else {}
        items = shop.get("items", [])
        add("current_shop_known", shop_known)
        add("current_shop_opportunity_closed", closed_shop)
        for category in ("card", "relic", "potion", "card_removal"):
            group = [x for x in items if x.get("category") == category and x.get("is_stocked", True)]
            prices = [float(x["price"]) for x in group if isinstance(x.get("price"), (float, int))]
            add("stock_count_" + category, len(group), 10)
            add("affordable_count_" + category, sum(0 <= p <= gold for p in prices), 10)
            add("lowest_price_" + category, min(prices, default=0), 300)
            add("price_known_" + category, bool(prices))
        # Optional completed, legally replayed forecasts. Missing/censored is
        # masked, never converted to an observed death or zero HP outcome.
        for category in ("fight", "elite", "boss"):
            observed = [r for r in capability or [] if r.get("category") == category
                        and r.get("complete") is True and r.get("legallyReplayed") is True]
            add("capability_known_" + category, bool(observed))
            add("capability_cases_" + category, len(observed), 10)
            for name, scale in (("survived", 1), ("hpCostFraction", 1), ("potionCost", 80), ("turns", 20)):
                known = [float(r[name]) for r in observed if r.get(name) is not None]
                add("capability_" + category + "_" + name + "_known", bool(known))
                add("capability_" + category + "_" + name, sum(known) / max(1, len(known)), scale)
        if self.names is not None and names != self.names:
            raise ValueError("Public feature schema changed")
        self.names = names
        return values
