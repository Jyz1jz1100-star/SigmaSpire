"""Gradient-trained public whole-run value with masked factual/teacher heads.

Native returns are policy-conditional observations. Legal same-scene combat
teachers supervise their own heads; they never become invented native wins.
"""
import copy

import torch
from torch import nn
from torch.nn import functional as F

from .codec import SCHEMA
from .inference import HEADS
from .data import verify_whole_seed_split, seeded_split


class JointValueNet(nn.Module):
    def __init__(self, width, dropout=.15):
        super().__init__()
        self.layers = nn.Sequential(nn.Linear(width, 128), nn.ReLU(), nn.Dropout(dropout),
                                    nn.Linear(128, 64), nn.ReLU(), nn.Dropout(dropout),
                                    nn.Linear(64, len(HEADS)))

    def forward(self, features):
        return self.layers(features)

    def export(self, tokens, feature_names, training):
        if training.get("optimizerSteps", 0) <= 0:
            raise ValueError("Cannot deploy an untrained value network")
        return dict(featureSchema=SCHEMA, featureNames=list(feature_names), headOrder=list(HEADS),
                    tokens=copy.deepcopy(tokens), training=copy.deepcopy(training),
                    layers=[dict(weight=layer.weight.detach().cpu().tolist(),
                                 bias=layer.bias.detach().cpu().tolist())
                            for layer in self.layers if isinstance(layer, nn.Linear)])


def masked_losses(prediction, target, mask, weight):
    if prediction.shape != target.shape or target.shape != mask.shape or prediction.shape[-1] != len(HEADS):
        raise ValueError("Joint value target schema mismatch")
    if not torch.isfinite(target).all() or not torch.isfinite(mask).all():
        raise ValueError("Unknown targets must use finite placeholders and zero masks")
    losses = torch.cat((F.binary_cross_entropy_with_logits(prediction[:, :3], target[:, :3], reduction="none"),
                        F.smooth_l1_loss(prediction[:, 3:], target[:, 3:], reduction="none")), dim=-1)
    sample_weight = mask * weight[:, None]
    totals = sample_weight.sum(dim=0)
    per_head = (losses * sample_weight).sum(dim=0) / totals.clamp_min(1e-12)
    return per_head, totals > 0


def objective(prediction, target, mask, weight, head_weights=None):
    losses, available = masked_losses(prediction, target, mask, weight)
    scales = prediction.new_tensor(head_weights or [1., 1., 1., 2., 2., .25])
    return (losses * scales * available).sum() / (scales * available).sum().clamp_min(1e-12)


