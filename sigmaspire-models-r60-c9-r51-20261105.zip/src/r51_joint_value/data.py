"""Build auditable vectors from the uniform native opportunity audit."""
import gzip
import hashlib
import json
from collections import Counter

from .public_map import remaining_board


def seeded_split(seed, salt="r51-public-joint-value-20261104"):
    return "development" if int(hashlib.sha256((salt + ":" + seed).encode()).hexdigest()[:8], 16) % 5 == 0 else "train"


def verify_whole_seed_split(rows):
    assignments = {}
    for row in rows:
        seed, split = row["sourceSeed"], row["split"]
        if split not in ("train", "development"):
            raise ValueError("Final holdouts cannot enter fitting or checkpoint selection")
        if seed in assignments and assignments[seed] != split:
            raise ValueError("A whole native seed crosses the split")
        assignments[seed] = split
        if row.get("causalActionLabel"):
            raise ValueError("Native return cannot claim a causal optimal action")
        if row.get("systemFailure") and row["mask"][0]:
            raise ValueError("Engineering failure is not a negative policy label")
        if row.get("censored") and any(row["mask"][1:]):
            raise ValueError("Censored combat outcome is not a terminal teacher")
        if any(row["mask"][1:]):
            proof = row.get("teacherProof", {})
            if not (proof.get("complete") is True and proof.get("legallyReplayed") is True
                    and proof.get("cleanupConfirmed") is True and proof.get("modelSha256")
                    and proof.get("resultSha256") and proof.get("resultPath")):
                raise ValueError("Combat labels require completed legal replay and model/result provenance")
    return assignments


def rows_from_audit(folder, codec, assignments):
    rows, sources, seen = [], {}, set()
    for path in sorted(folder.glob("*-decisions.jsonl.gz")):
        sources[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        report = json.loads(path.with_name(path.name.replace("-decisions.jsonl.gz", ".json")).read_text(encoding="utf-8"))
        policy = "candidate009" if report["arm"] == "candidate" else "other"
        # Some registrations use a longer candidate arm label. Resolve from the
        # explicit audit arm, never from the seed, gold or terminal result.
        if "candidate" in str(report["arm"]).lower():
            policy = "candidate009"
        accepted_map = {r["decisionId"]: r["index"] for r in report.get("acceptedMapActions", [])}
        accepted_proceed = {r["decisionId"] for r in report.get("acceptedShopActions", [])
                            if r["payload"].get("action") == "proceed"}
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            for line in stream:
                source = json.loads(line)
                seed = source["sourceSeed"]
                split = assignments[seed]
                if split == "final_holdout":
                    continue
                state = source["state"]
                board = None
                if state.get("state_type") == "map":
                    board = state["map"]
                elif source.get("publicMapAct") == state.get("run", {}).get("act"):
                    previous, entered = source.get("lastObservedPublicMap"), source.get("enteredPublicNode")
                    if previous is not None and entered is not None:
                        board = remaining_board(previous, entered)
                selected = accepted_map.get(state.get("decision_id")) if state.get("state_type") == "map" else None
                vector = codec.encode(state, board=board, option_index=selected, policy=policy)
                # Deduplicate semantically identical observations within a run;
                # polling duration and changing decision tokens have no weight.
                signature = (source["sourceOutput"], tuple(vector))
                if signature in seen:
                    continue
                seen.add(signature)
                target = source.get("policyConditionalFullWin")
                rows.append(dict(sourceSeed=seed, split=split, policy=policy,
                    sourceOutput=source["sourceOutput"], sourceSequence=source["sourceSequence"],
                    features=vector, target=[float(target or 0), 0., 0., 0., 0., 0.],
                    mask=[float(target is not None), 0., 0., 0., 0., 0.],
                    systemFailure=target is None, causalActionLabel=False))
                if state.get("state_type") == "shop" and state.get("decision_id") in accepted_proceed:
                    rows.append(dict(sourceSeed=seed, split=split, policy=policy,
                        sourceOutput=source["sourceOutput"], sourceSequence=source["sourceSequence"],
                        features=codec.encode(dict(state, _r51_shop_closed=True), board=board, policy=policy),
                        target=[float(target or 0), 0., 0., 0., 0., 0.],
                        mask=[float(target is not None), 0., 0., 0., 0., 0.],
                        systemFailure=target is None, causalActionLabel=False,
                        labelSource="actual_native_committed_shop_proceed",
                        noLabelForUnchosenAlternative=True))
        for committed in report.get("committedCardRewardStates",[]):
            seed=report["seed"]
            if assignments[seed]=="final_holdout":
                continue
            state=dict(committed["state"],state_type="card_reward",_r51_card_reward_closed=True)
            board=committed.get("publicMap") if committed.get("publicMapAct")==state["run"].get("act") else None
            if board and committed.get("enteredPublicNode"):
                board=remaining_board(board,committed["enteredPublicNode"])
            target=report["policyConditionalFullWin"]
            rows.append(dict(sourceSeed=seed,split=assignments[seed],policy=policy,sourceOutput=report["output"],
                sourceSequence=committed["sequence"],features=codec.encode(state,board=board,policy=policy),
                target=[float(target or 0),0.,0.,0.,0.,0.],mask=[float(target is not None),0.,0.,0.,0.,0.],
                systemFailure=target is None,causalActionLabel=False,labelSource="actual_native_after_card_reward_commit",
                noLabelForUnchosenAlternative=True))
        for root in report.get("nativeBossRoots", []):
            proof = root["nativeProof"]
            if (assignments[report["seed"]] == "final_holdout" or root["bossSurvived"] is None
                    or not proof.get("modelSha256") or not proof.get("legallyReplayed")):
                continue
            state = dict(root["state"], state_type="combat")
            board = None
            if root.get("publicMapAct") == state["run"]["act"] and root.get("publicMap") and root.get("enteredPublicNode"):
                board = remaining_board(root["publicMap"], root["enteredPublicNode"])
            target = report["policyConditionalFullWin"]
            rows.append(dict(sourceSeed=report["seed"], split=assignments[report["seed"]], policy=policy,
                sourceOutput=report["output"], sourceSequence=root["sequence"],
                features=codec.encode(state, board=board, policy=policy),
                target=[float(target or 0), float(root["bossSurvived"]), 0., 0., 0., 0.],
                mask=[float(target is not None), 1., 0., 0., 0., 0.],
                teacherProof=proof, labelSource="actual_native_policy_combat", causalActionLabel=False,
                systemFailure=target is None, nativeHpCostMasked=True))
    counts = Counter((r["sourceSeed"], r["sourceOutput"]) for r in rows)
    runs_per_seed = Counter(seed for seed, output in counts)
    for row in rows:
        row["weight"] = 1 / runs_per_seed[row["sourceSeed"]] / counts[row["sourceSeed"], row["sourceOutput"]]
        row["policyTagScope"] = "Combat component; native return belongs to the source registered whole-run behavior"
    return rows, dict(sources=sources, equalSeedThenRunThenSemanticState=True,
                      nativeReturnIsPolicyConditional=True, noCausalOptimalActionLabels=True)
