"""Training-only empirical prices, conditional on visiting an unknown shop.

This is a policy-conditioned distribution, not a prediction of future stock.
Whole visits/seeds are the units of uncertainty; repeated paired visits do not
pretend to be independent evidence. No held-out or live future shop is read.
"""
import hashlib
import json
import math
from collections import defaultdict

CATEGORIES = ("card", "relic", "potion", "card_removal")


def fit_market(reports, assignments):
    groups, seen = defaultdict(list), set()
    for report in reports:
        seed = report["seed"]
        if assignments[seed] != "train":
            continue
        for shop in report["shops"]:
            items = [dict(category=x["category"], price=float(x["price"]))
                     for x in shop["offeredItems"] if x.get("is_stocked") is True
                     and x.get("category") in CATEGORIES and isinstance(x.get("price"), (int, float))
                     and x["price"] >= 0]
            items.sort(key=lambda x: (x["category"], x["price"]))
            signature = (seed, tuple(shop["location"]), json.dumps(items, sort_keys=True))
            if signature in seen:
                continue
            seen.add(signature)
            groups[str(shop["location"][0])].append(dict(sourceSeed=seed, prices=items))
    return dict(schema="r51-training-observed-shop-prices-v1", byAct=dict(groups),
                conditionalOnObservedPolicyVisit=True, futureInventoryPrediction=False,
                sourceSeeds=sorted({row["sourceSeed"] for group in groups.values() for row in group}),
                wholeSeedTrainOnly=True, pairedIdenticalVisitsDeduplicated=True)


def market_features(distribution, act, gold):
    visits = (distribution or {}).get("byAct", {}).get(str(act), [])
    by_seed = defaultdict(list)
    for visit in visits:
        by_seed[visit["sourceSeed"]].append(visit["prices"])
    result = dict(price_distribution_known=float(bool(by_seed)),
                  price_distribution_seed_count=len(by_seed) / 20)
    for category in CATEGORIES:
        seed_probabilities, seed_counts, seed_min_prices = [], [], []
        for seed_visits in by_seed.values():
            probabilities, counts, minimums = [], [], []
            for visit in seed_visits:
                prices = [item["price"] for item in visit if item["category"] == category]
                counts.append(sum(price <= gold for price in prices))
                probabilities.append(float(any(price <= gold for price in prices)))
                if prices:
                    minimums.append(min(prices))
            seed_probabilities.append(sum(probabilities) / len(probabilities))
            seed_counts.append(sum(counts) / len(counts))
            if minimums:
                seed_min_prices.append(sum(minimums) / len(minimums))
        n = len(seed_probabilities)
        mean = sum(seed_probabilities) / max(1, n)
        # Jeffreys-smoothed Bernoulli uncertainty has a positive floor even
        # when all observed seeds agree; zero price uncertainty is not claimed.
        smooth = (sum(seed_probabilities) + .5) / (n + 1)
        uncertainty = math.sqrt(smooth * (1 - smooth) / (n + 2)) if n else 0.
        result[category + "_any_affordable"] = mean
        result[category + "_affordable_count"] = sum(seed_counts) / max(1, n) / 10
        result[category + "_affordability_uncertainty"] = uncertainty
        result[category + "_mean_min_price"] = sum(seed_min_prices) / max(1, len(seed_min_prices)) / 300
        result[category + "_price_known"] = float(bool(seed_min_prices))
    return result
