"""Reuse legal known-stock combinations and represent full-slot replacement.

Discarding is only a candidate preparation, selected by the same value model;
it never happens just because the old behavior policy proposed a discard.
"""
import copy
from collections import defaultdict, deque
from itertools import combinations, product


def balanced_visible_combinations(state, max_combinations=128):
    """All legal singles, then category/item round robin at each depth.

    Reuse the existing variants/estimate and Python's itertools round-robin
    recipe; neither early item indices nor many removal variants monopolize
    the bounded pair/triple budget. No learned score filters enumeration.
    https://docs.python.org/3/library/itertools.html#itertools-recipes
    """
    from shop_planner_r2 import purchase_variants, estimate
    variants = purchase_variants(state)
    plans = [estimate(state, [])] + [estimate(state, [variant]) for variant in variants]
    grouped = defaultdict(list)
    for variant in variants:
        grouped[variant["item"]["index"]].append(variant)
    for depth, quota in ((2, (max_combinations + 1) // 2), (3, max_combinations // 2)):
        categories = defaultdict(deque)
        for indices in combinations(sorted(grouped), depth):
            items = [grouped[i][0]["item"] for i in indices]
            if sum(item["price"] for item in items) > state["player"]["gold"]:
                continue
            kind = tuple(sorted(item["category"] for item in items))
            categories[kind].append(iter(product(*(grouped[i] for i in indices))))
        active = deque(categories[kind] for kind in sorted(categories))
        added = 0
        while active and added < quota:
            streams = active.popleft()
            while streams:
                stream = streams.popleft()
                try:
                    sequence = next(stream)
                except StopIteration:
                    continue
                streams.append(stream)
                plan = estimate(state, list(sequence))
                if plan is not None:
                    plans.append(plan)
                    added += 1
                    break
            if streams:
                active.append(streams)
    return plans


def native_action(plan):
    if plan.get("preparation"):
        return dict(plan["preparation"])
    if plan["sequence"]:
        return dict(action="shop_purchase", index=plan["sequence"][0]["item"]["index"])
    return dict(action="proceed")


def enumerate_known_shop(state):
    from .probe_loadout import PUBLIC_INTEGER_COUNTERS
    plans = balanced_visible_combinations(state)
    held = [p for p in state["player"].get("potions", []) if p.get("id")]
    capacity = state["player"]["max_potion_slots"]
    if capacity and len(held) == capacity:
        for index, potion in enumerate(held):
            slot = potion.get("slot", index)
            frame = copy.deepcopy(state)
            frame["player"]["potions"] = [p for i, p in enumerate(held) if i != index]
            # Keep all replacement singles; bound extra multi-purchase plans.
            alternatives = balanced_visible_combinations(frame, max_combinations=32)
            for plan in alternatives:
                if any(v["item"]["category"] == "potion" for v in plan["sequence"]):
                    plan["preparation"] = dict(action="discard_potion", slot=slot)
                    plan["uncertainties"] = sorted(set(plan["uncertainties"] + [
                        "potion_discard_requires_fresh_native_state_and_complete_replanning"]))
                    plans.append(plan)
    for plan in plans:
        acquired = {v["item"].get("relic_id") for v in plan["sequence"] if v["item"]["category"] == "relic"}
        for relic in plan["state"]["player"]["relics"]:
            if relic["id"] in acquired and relic["id"] in PUBLIC_INTEGER_COUNTERS and relic.get("counter") is None:
                # Audited new constructors start these visible phases at zero.
                relic["counter"] = 0
                relic["_r51_audited_new_relic_counter"] = True
    return plans
