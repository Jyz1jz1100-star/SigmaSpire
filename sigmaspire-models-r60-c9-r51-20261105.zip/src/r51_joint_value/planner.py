"""Joint route/shop ranking with public context and first-action replanning.

The existing native-visible purchase enumerator supplies affordable singles and
bounded combinations. Every generated plan reaches the learned value before a
combat shortlist is made. There is no fixed per-coin cost or forced purchase.
"""
import copy


def first_key(plan):
    if plan.get("preparation"):
        return tuple(sorted(plan["preparation"].items()))
    if not plan["sequence"]:
        return ("proceed",)
    first = plan["sequence"][0]
    return (first["item"]["index"], first.get("removal", {}).get("deck_index"))


def rank_shop(state, plans, predictor, *, board=None, capability_by_plan=None):
    if not plans or not any(not p["sequence"] for p in plans):
        raise ValueError("A legal no-purchase alternative is required")
    ranked = []
    for index, plan in enumerate(plans):
        if plan is None or plan["spent"] < 0 or plan["spent"] > state["player"]["gold"]:
            raise ValueError("Purchase enumerator returned an invalid budget")
        context = dict(board=board, policy="candidate009")
        if capability_by_plan is not None:
            context["capability"] = capability_by_plan.get(index, [])
        # Compare completed shopping commitments with the current opportunity
        # closed. A no-buy/proceed action must not retain the ability to buy the
        # same visible stock in its value bootstrap.
        valued_state = dict(plan["state"], _r51_shop_closed=True)
        prediction = predictor.predict(valued_state, **context)
        ranked.append(dict(plan=plan, sourcePlanIndex=index, prediction=prediction,
                           value=prediction["native_policy_win_logit"]))
    # Coin balance is already an input to the learned value. Spending is only a
    # stable tie break for exactly equal predicted values.
    return sorted(ranked, key=lambda r: (-r["value"], r["plan"]["spent"], len(r["plan"]["sequence"]),
                                         r["sourcePlanIndex"]))


def combat_shortlist(ranked, maximum=4):
    if maximum < 2:
        raise ValueError("Forecast capacity must retain baseline and an alternative")
    baseline = next(r for r in ranked if not r["plan"]["sequence"])
    chosen = [baseline]
    for row in ranked:
        if len(chosen) >= maximum:
            break
        if first_key(row["plan"]) not in {first_key(r["plan"]) for r in chosen}:
            chosen.append(row)
    return chosen


def rank_routes(state, predictor, *, capability_by_option=None):
    if state.get("state_type") != "map":
        raise ValueError("A current native map state is required")
    ranked = []
    for option in state["map"]["next_options"]:
        prediction = predictor.predict(state, board=state["map"], option_index=option["index"],
                                       policy="candidate009",
                                       capability=(capability_by_option or {}).get(option["index"], []))
        ranked.append(dict(index=option["index"], prediction=prediction,
                           value=prediction["native_policy_win_logit"]))
    if not ranked:
        raise ValueError("No publicly reachable route action")
    return sorted(ranked, key=lambda row: (-row["value"], row["index"]))


def rank_card_rewards(state, predictor, *, board=None):
    reward = state["card_reward"]
    candidates = []
    if reward.get("can_skip", True):
        candidates.append((dict(action="skip_card_reward"), None))
    candidates += [(dict(action="select_card_reward",card_index=card["index"]),card)
                   for card in reward.get("cards",[])]
    ranked = []
    for payload,card in candidates:
        frame = copy.deepcopy(state)
        frame["_r51_card_reward_closed"] = True
        if card is not None:
            frame["player"]["deck"].append(copy.deepcopy(card))
        prediction = predictor.predict(frame,board=board,policy="candidate009")
        ranked.append(dict(payload=payload,prediction=prediction,value=prediction["native_policy_win_logit"],
            acquisitionHooksRequireFreshNativeState=card is not None))
    return sorted(ranked,key=lambda r:(-r["value"],r["payload"]["action"]!="skip_card_reward",r["payload"].get("card_index",-1)))
