"""On-demand owned-process peaks and system commit; no background monitor.

Use the documented Win32 PSAPI structures, alongside the existing bounded
host's CPU counters. Page-fault totals include soft faults and are not evidence
of disk paging or thrashing by themselves.
https://learn.microsoft.com/windows/win32/api/psapi/ns-psapi-process_memory_counters_ex
https://learn.microsoft.com/windows/win32/api/psapi/ns-psapi-performance_information
"""
import ctypes
from ctypes import wintypes as W
import json
import time

from r27_capability.host import BoundedCapabilityHost

PSAPI = ctypes.WinDLL("psapi", use_last_error=True)


class ProcessMemory(ctypes.Structure):
    _fields_ = [("cb", W.DWORD), ("PageFaultCount", W.DWORD)] + [(name, ctypes.c_size_t) for name in (
        "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage", "QuotaPagedPoolUsage",
        "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage", "PrivateUsage")]


class Performance(ctypes.Structure):
    _fields_ = [("cb", W.DWORD)] + [(name, ctypes.c_size_t) for name in (
        "CommitTotal", "CommitLimit", "CommitPeak", "PhysicalTotal", "PhysicalAvailable", "SystemCache",
        "KernelTotal", "KernelPaged", "KernelNonpaged", "PageSize")] + [(name, W.DWORD) for name in (
        "HandleCount", "ProcessCount", "ThreadCount")]


PSAPI.GetProcessMemoryInfo.argtypes = [W.HANDLE, ctypes.POINTER(ProcessMemory), W.DWORD]
PSAPI.GetProcessMemoryInfo.restype = W.BOOL
PSAPI.GetPerformanceInfo.argtypes = [ctypes.POINTER(Performance), W.DWORD]
PSAPI.GetPerformanceInfo.restype = W.BOOL


def system_memory():
    counters = Performance()
    counters.cb = ctypes.sizeof(counters)
    if not PSAPI.GetPerformanceInfo(ctypes.byref(counters), counters.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    page = counters.PageSize
    return dict(availablePhysicalBytes=counters.PhysicalAvailable * page,
        totalPhysicalBytes=counters.PhysicalTotal * page, commitBytes=counters.CommitTotal * page,
        commitLimitBytes=counters.CommitLimit * page,
        commitHeadroomBytes=max(0, counters.CommitLimit - counters.CommitTotal) * page,
        pagingThrashMeasured=False)


def owned_memory(process):
    counters = ProcessMemory()
    counters.cb = ctypes.sizeof(counters)
    if not PSAPI.GetProcessMemoryInfo(W.HANDLE(int(process._handle)), ctypes.byref(counters), counters.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return dict(workingSetBytes=counters.WorkingSetSize, peakWorkingSetBytes=counters.PeakWorkingSetSize,
        privateCommitBytes=counters.PrivateUsage, peakPrivateCommitBytes=counters.PeakPagefileUsage,
        pageFaultCount=counters.PageFaultCount, pageFaultCountIncludesSoftFaults=True)


class MeteredCapabilityHost(BoundedCapabilityHost):
    def close(self, force=False):
        if getattr(self, "_metered_final", False) and getattr(self, "_closed", False):
            return
        observation = dict(sampledAtCloseMonotonic=time.monotonic(), noBackgroundMonitor=True)
        process = getattr(self, "process", None)
        if process is not None and process.poll() is None:
            try:
                observation.update(owned_memory(process))
                observation["systemMemoryBeforeClose"] = system_memory()
            except OSError as error:
                observation["sampleError"] = repr(error)
        try:
            return super().close(force=force)
        finally:
            observation["timing"] = getattr(self, "timings", {})
            if getattr(self, "directory", None) is not None:
                cleanup_path = self.directory / "cleanup.json"
                cleanup = json.loads(cleanup_path.read_text(encoding="utf-8")) if cleanup_path.exists() else {}
                observation["cleanupConfirmed"] = cleanup.get("bothConfirmed") is True
                (self.directory / "resource-usage.json").write_text(json.dumps(observation), encoding="utf-8")
            self._metered_final = bool(getattr(self, "_closed", False))
