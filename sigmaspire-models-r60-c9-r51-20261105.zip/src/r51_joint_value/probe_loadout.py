"""Preserve audited visible relic counters and gold in new-version probes.

Do not infer arbitrary saved properties from a display counter. Unmapped
persistent state is explicitly unsupported, never silently an exact restore.
"""
import copy

PUBLIC_INTEGER_COUNTERS = {"HAPPY_FLOWER": "TurnsSeen", "SWORD_OF_STONE": "ElitesDefeated",
                           "PEN_NIB": "AttacksPlayed", "BOOK_OF_FIVE_RINGS": "CardsAdded"}
AUDITED_STATELESS = {"ICE_CREAM", "RINGING_TRIANGLE", "RUNIC_PYRAMID", "STURDY_CLAMP",
                     "BURNING_BLOOD", "BOOMING_CONCH", "GORGET", "PAELS_FLESH",
                     # Pinned game decompilation, visible-relic-state-audit-01:
                     # no run-persistent members; combat-local flags reset by
                     # ordinary new-combat initialization/end hooks. One-shot
                     # obtained effects are already reflected in observed
                     # HP/deck/gold/capacity, never reapplied to an owned relic.
                     "KALEIDOSCOPE", "BIIIG_HUG", "ARCANE_SCROLL", "PRECISE_SCISSORS",
                     "KUSARIGAMA", "BLOOD_VIAL", "MINIATURE_CANNON", "BAG_OF_PREPARATION",
                     "PAELS_TEARS", "SAND_CASTLE", "STONE_CRACKER", "PEAR", "PRECARIOUS_SHEARS",
                     "TINY_MAILBOX", "POTION_BELT", "MR_STRUGGLES", "AMETHYST_AUBERGINE",
                     "LARGE_CAPSULE", "BOWLER_HAT", "WHETSTONE", "ORICHALCUM", "GREMLIN_HORN",
                     "DIAMOND_DIADEM", "ETERNAL_FEATHER", "REGAL_PILLOW", "CENTENNIAL_PUZZLE",
                     "PANTOGRAPH", "HORN_CLEAT", "LANTERN", "ART_OF_WAR", "GOLDEN_PEARL"}


def public_player_payload(state, request):
    request = copy.deepcopy(request)
    player = state["player"]
    visible = player.get("relics", [])
    if len(visible) != len(request["relics"]):
        raise ValueError("Requested relics differ from visible/hypothetical loadout")
    unsupported, reasons = [], []
    for relic, injection in zip(visible, request["relics"]):
        if relic["id"] != injection["relicId"]:
            raise ValueError("Requested relic identity differs")
        identity, counter = relic["id"], relic.get("counter")
        if identity in PUBLIC_INTEGER_COUNTERS:
            if not isinstance(counter, int):
                unsupported.append(identity)
                reasons.append(dict(id=identity,reason="Audited public counter unavailable"))
                continue
            if identity == "HAPPY_FLOWER" and not 0 <= counter <= 2:
                unsupported.append(identity)
                reasons.append(dict(id=identity,reason="Transient activation is not a saved modulo-three phase"))
                continue
            if identity == "PEN_NIB" and not 0 <= counter <= 9:
                unsupported.append(identity)
                reasons.append(dict(id=identity,reason="Transient activation is not a saved pre-combat phase"))
                continue
            if identity == "BOOK_OF_FIVE_RINGS" and not 0 <= counter <= 4:
                unsupported.append(identity)
                reasons.append(dict(id=identity,reason="Transient activation is not a saved modulo-five phase"))
                continue
            injection.setdefault("integerMembers", {})[PUBLIC_INTEGER_COUNTERS[identity]] = counter
        elif identity not in AUDITED_STATELESS:
            unsupported.append(identity)
    public = dict(gold=player["gold"], relics=[dict(id=r["id"], counter=r.get("counter")) for r in visible])
    return request, public, dict(unsupportedRelicStateIds=unsupported,
        unsupportedPublicStateReasons=reasons,
        exactVisiblePreCombatFields=not unsupported,
        exactNativeContinuation=False, scope="Hypothetical combat under documented public loadout assumptions")
