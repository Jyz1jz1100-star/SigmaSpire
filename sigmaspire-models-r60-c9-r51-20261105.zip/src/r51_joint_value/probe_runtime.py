"""Process-local public-player restoration on the independent R51 host."""
from pathlib import Path
from importlib import import_module
import functools
import hashlib
import json
import time
import sys

from .resources import MeteredCapabilityHost
from .probe_loadout import public_player_payload


def pinned_combat_environment(root):
    bindings = json.loads((root / "runs/r49-hash-settlement-20261103-001/deployment-bindings-candidate009.json").read_text(encoding="utf-8-sig"))
    environment = {"ENGINEERING_EXACT_VALUE_CACHE":"1"}
    for role, prefix in (("auxiliary", "NEURAL_AUXILIARY"), ("student", "NEURAL_SPECIALIST"),
                         ("rlProposal", "RL_PROPOSAL"), ("afterstate", "AFTERSTATE")):
        binding = bindings["bindings"][role]
        path = (root / binding["model"]).resolve()
        if not path.is_relative_to(root / "models") or hashlib.sha256(path.read_bytes()).hexdigest() != binding["modelSha256"]:
            raise ValueError("Pinned C9 combat sidecar changed")
        environment["ENGINEERING_" + prefix + "_MODEL_PATH"] = str(path)
        environment["ENGINEERING_" + prefix + "_MODEL_SHA256"] = binding["modelSha256"]
    return environment


def install(root):
    for directory in (root / "src/r8_terminal_run_bridge", root / "src/r4_startup_binding_client"):
        if str(directory) not in sys.path:
            sys.path.insert(0, str(directory))
    host_path = (root / "src/r51_runtime_harness/bin/Release/net9.0/OfflineSearchHarness.dll").resolve()
    combat_environment = pinned_combat_environment(root)

    class PublicPlayerHost(MeteredCapabilityHost):
        def __init__(self, request, *args, **kwargs):
            source = json.loads(Path(request).read_text(encoding="utf-8-sig"))
            public = source.pop("engineeringPublicPlayer", None)
            support = source.pop("engineeringPublicPlayerSupport", None)
            if public is not None:
                runtime = kwargs.get("config") or {}
                configured = (root / runtime.get("host_dll", "")).resolve()
                if configured != host_path:
                    raise ValueError("Public loadout request requires the independently registered R51 host")
                # Reused short probes cap protocol waits at30s. Explicit long
                # teachers need a matching bounded response wait; cancellation
                # and the outer request deadline remain authoritative.
                if kwargs.get("budget_ms", 0) > 25000:
                    remaining = max(.001, kwargs.get("deadline", time.monotonic() + 240) - time.monotonic())
                    kwargs["config"] = dict(runtime, process_timeout_seconds=min(remaining,
                        max(runtime.get("process_timeout_seconds", 30), kwargs["budget_ms"] / 1000 + 5)))
                out = Path(kwargs["out"])
                out.parent.mkdir(parents=True, exist_ok=True)
                # CombatHost owns creation of its new output directory.
                # Keep adaptation files beside it until the host is created.
                clean = out.parent / "public-player-host-request.json"
                clean.write_text(json.dumps(source), encoding="utf-8")
                (out.parent / "public-player-support.json").write_text(json.dumps(support), encoding="utf-8")
                env = dict(combat_environment)
                env.update(kwargs.get("process_env") or {})
                env["ENGINEERING_PROBE_PUBLIC_PLAYER"] = json.dumps(public)
                env["ENGINEERING_R51_MIN_AVAILABLE_MIB"] = str(runtime.get("minimum_available_mib", 3584))
                kwargs["process_env"] = env
                request = clean
            completed=False
            try:
                super().__init__(request, *args, **kwargs)
                completed=True
            finally:
                output=Path(kwargs["out"])
                output.parent.mkdir(parents=True,exist_ok=True)
                process=getattr(self,"process",None)
                (output.parent/"host-creation.json").write_text(json.dumps(dict(factoryFinished=True,
                    constructorCompleted=completed,actualHostStarted=process is not None,
                    processId=process.pid if process is not None else None)),encoding="utf-8")

    def wrap(function):
        if getattr(function, "_r51_public_player", False):
            return function

        @functools.wraps(function)
        def request_for(state, *args, **kwargs):
            request = function(state, *args, **kwargs)
            request, public, support = public_player_payload(state, request)
            request["engineeringPublicPlayer"] = public
            request["engineeringPublicPlayerSupport"] = support
            return request
        request_for._r51_public_player = True
        return request_for

    def wrap_replay(function):
        if getattr(function, "_r51_public_player_result", False):
            return function

        @functools.wraps(function)
        def replay(request, output, *args, **kwargs):
            result = function(request, output, *args, **kwargs)
            if isinstance(result, dict):
                support = request.get("engineeringPublicPlayerSupport") or {}
                result["publicPlayerStateSupported"] = support.get("exactVisiblePreCombatFields", False)
                result["publicPlayerStateSupport"] = support
                guard_path = Path(output) / "host/stderr.log"
                if guard_path.exists():
                    with guard_path.open(encoding="utf-8-sig") as stream:
                        for line in stream:
                            marker="ENGINEERING_HARD_NODE_ADMISSION "
                            if marker not in line:
                                continue
                            report=json.JSONDecoder().raw_decode(line.split(marker,1)[1])[0]
                            if report.get("resourceStopped") is True:
                                result.update(observedTerminalBeforeResourceCensor=result.get("terminal"),
                                    terminal=False,censored=True,censorReason="physical_or_commit_resource_guard",
                                    resourceGuardReport=report,resourceEstimate="unknown_resource_guard_interruption")
                                break
                (Path(output) / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
            return result
        replay._r51_public_player_result = True
        return replay

    # Import the active reused adapters, then replace their captured request
    # function references too. This never edits their source files or globals
    # in the separate frozen native controller process.
    names = ("replay_probe_r1", "replay_probe_cache_r5", "resource_choice_r1", "combat_choice_r1",
             "combat_choice_ensemble_r4", "combat_choice_m18", "probe_scheduler_r1", "probe_scheduler_cache_r5")
    patched = []
    for name in names:
        module = import_module(name)
        if hasattr(module, "request_for"):
            module.request_for = wrap(module.request_for)
            patched.append(name)
        if name in ("replay_probe_r1", "replay_probe_cache_r5"):
            module.CombatHost = PublicPlayerHost
        if hasattr(module, "replay_probe"):
            module.replay_probe = wrap_replay(module.replay_probe)
    return dict(host=str(host_path.relative_to(root)), requestAdapters=patched,
                cleanup="bounded handle/process/reader confirmation", exactNativeContinuation=False,
                unsupportedRelicStateRemainsExplicit=True)
