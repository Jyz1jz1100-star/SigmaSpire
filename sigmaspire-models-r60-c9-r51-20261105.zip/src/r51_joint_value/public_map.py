"""Public DAG shop opportunities; no inventory or future random outcomes.

Extends the public topology contract in scripts/public_route_suffix_r4.py.
Memoized suffix statistics replace enumeration while retaining alternatives.
"""
from functools import lru_cache


def remaining_board(board, position):
    """Scope a previously observed map to an actually entered public node.

    A shop/event can keep the last map's topology, but must not regain access
    to unchosen sibling branches. Contents and future RNG are never copied.
    """
    nodes = {(n["col"], n["row"]): n for n in board.get("nodes", [])}
    coord = position["col"], position["row"]
    if coord not in nodes:
        raise ValueError("Entered position is absent from observed map")
    children = nodes[coord].get("children", [])
    options = []
    for i, child in enumerate(children):
        target = nodes.get(tuple(child))
        if target is None:
            # Preserve an incomplete edge so the opportunity mask stays false.
            target = dict(col=child[0], row=child[1], type="Unknown")
        options.append(dict(index=i, col=target["col"], row=target["row"], type=target["type"]))
    return {k: board[k] for k in ("nodes", "boss", "bosses") if k in board} | dict(
        current_position=dict(position), next_options=options)


def public_options(board):
    nodes = {(n["col"], n["row"]): n for n in board.get("nodes", [])}
    if len(nodes) != len(board.get("nodes", [])):
        raise ValueError("Duplicate public map coordinate")
    active = set()

    @lru_cache(maxsize=None)
    def visit(coord):
        if coord in active:
            raise ValueError("Public map contains a cycle")
        if coord not in nodes:
            return dict(complete=False, shops=frozenset(), minShops=0, maxShops=0,
                        minFights=0, maxFights=0, minElites=0, maxElites=0,
                        minUnknown=0, maxUnknown=0, minRests=0, maxRests=0,
                        firstShop=None, firstRest=None, paths=0)
        active.add(coord)
        node = nodes[coord]
        kind = node["type"]
        children = [visit(tuple(child)) for child in node.get("children", [])]
        shop, fight, elite, unknown = (int(kind == "Shop"), int(kind in ("Monster", "Elite")),
                                      int(kind == "Elite"), int(kind == "Unknown"))
        shops = ({coord} if shop else set()).union(*(x["shops"] for x in children))
        first = dict(distance=0, fights=0, elites=0, path=[coord]) if shop else None
        access = []
        for child in children:
            if child["firstShop"] is not None:
                target = child["firstShop"]
                access.append(dict(distance=target["distance"] + 1, fights=target["fights"] + fight,
                                   elites=target["elites"] + elite, path=[coord] + target["path"]))
        if first is None and access:
            first = min(access, key=lambda x: (x["elites"], x["fights"], x["distance"], x["path"]))
        rest = dict(distance=0, fights=0, elites=0, path=[coord]) if kind == "RestSite" else None
        rest_access = []
        for child in children:
            if child["firstRest"] is not None:
                target = child["firstRest"]
                rest_access.append(dict(distance=target["distance"] + 1, fights=target["fights"] + fight,
                    elites=target["elites"] + elite, path=[coord] + target["path"]))
        if rest is None and rest_access:
            rest = min(rest_access, key=lambda x: (x["elites"], x["fights"], x["distance"], x["path"]))
        value = dict(complete=all(x["complete"] for x in children) and (bool(children) or kind == "Boss"),
                     shops=frozenset(shops), firstShop=first, firstRest=rest,
                     paths=sum(x["paths"] for x in children) if children else int(kind == "Boss"))
        for name, increment in (("Shops", shop), ("Fights", fight), ("Elites", elite), ("Unknown", unknown),
                                ("Rests", int(kind == "RestSite"))):
            value["min" + name] = increment + min((x["min" + name] for x in children), default=0)
            value["max" + name] = increment + max((x["max" + name] for x in children), default=0)
        active.remove(coord)
        return value

    result = []
    for option in board.get("next_options", []):
        coord = option["col"], option["row"]
        value = visit(coord)
        result.append(dict(index=option["index"], coordinate=list(coord),
                           reachableShopCoordinates=[list(c) for c in sorted(value["shops"])],
                           **{k: v for k, v in value.items() if k != "shops"}))
    current = board.get("current_position") or {}
    node = nodes.get((current.get("col"), current.get("row")), {})
    known_closed_suffix = not result and node.get("type") == "Boss" and not node.get("children")
    return dict(complete=(bool(result) and all(x["complete"] for x in result)) or known_closed_suffix, options=result,
                scope="Public topology counts and access lower bounds; unknown rooms have no assumed contents")


def lost_shop_access(board, selected_index):
    report = public_options(board)
    choices = {x["index"]: x for x in report["options"]}
    if selected_index not in choices:
        raise ValueError("Selected option is not publicly reachable")
    all_shops = {tuple(c) for x in choices.values() for c in x["reachableShopCoordinates"]}
    selected = {tuple(c) for c in choices[selected_index]["reachableShopCoordinates"]}
    return dict(report, selectedIndex=selected_index,
                forgoneShopCoordinates=[list(c) for c in sorted(all_shops - selected)],
                interpretation="Lost access is an opportunity observation, not proof the alternative was better")
