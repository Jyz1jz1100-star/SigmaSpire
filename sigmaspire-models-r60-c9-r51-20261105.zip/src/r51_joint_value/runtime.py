"""Process-local route/shop adapter for the independently registered R51 UI.

The C9 combat owner and native action codec remain the reused implementation.
This adapter owns only resource ranking; actual execution is one first action
with the normal fresh native decision token and transaction handling.
"""
from pathlib import Path
import copy
import json
import os
import time

from .inference import JointValue
from .planner import rank_shop, combat_shortlist, rank_routes,rank_card_rewards
from .public_map import remaining_board
from .shop_candidates import enumerate_known_shop, native_action


def completed_capabilities(probes, keys, common=None, maximum_hp=1):
    result = []
    allowed = range(len(probes)) if common is None else common
    for i in allowed:
        probe = probes[i]
        if probe is None or not probe.get("terminal") or probe.get("censored") or probe.get("publicPlayerStateSupported") is False:
            continue
        encounter = keys[i]["encounterId"]
        category = "boss" if encounter.endswith("_BOSS") else "elite" if encounter.endswith("_ELITE") else "fight"
        result.append(dict(category=category, complete=True, legallyReplayed=True,
            survived=bool(probe["victory"]), hpCostFraction=probe["hpLoss"] / max(1, maximum_hp),
            potionCost=probe.get("potionCost"), turns=probe.get("turns")))
    return result


def with_joint_value(base, binding, root):
    from r44_runtime.durable_owner import atomic_write

    class ResourceChoice(base):
        def __init__(self, engine):
            super().__init__(engine)
            overrides = binding.get("planningBudget") or {}
            if set(overrides) - {"workers", "decisionSeconds", "shopDecisionSeconds", "bossSeconds", "eliteSeconds", "fightSeconds"}:
                raise ValueError("Unsupported joint resource scheduling override")
            if overrides:
                workers = int(overrides.get("workers", self.budget["workers"]))
                if not 1 <= workers <= max(1, os.cpu_count() or 1):
                    raise ValueError("Resource worker count exceeds local CPU inventory")
                self.budget.update(overrides)
                self.scheduler.workers = workers
                self.scheduler.config.update(overrides)
            self.joint = JointValue(root / binding["model"], binding["sha256"])
            self.joint_board = None
            self.joint_act = None
            self.joint_entered = None
            self.joint_usage = dict(model=binding["model"], sha256=binding["sha256"],
                routeRankings=0, shopRankings=0, rewardRankings=0,forcedRouteObservations=0, predictions=0,
                exactNativeCounterfactualWinClaim=False, nativeReturnIsPolicyConditional=True)
            self._publish_usage()
            if hasattr(engine,"decide_reward"):
                # The existing owner calls this after its resource adapter.
                # Bind only this engine instance, never the frozen class/process.
                engine.decide_reward = self.decide_reward

        def decide_reward(self,state,heuristic):
            from advisor_core.live_candidate_codec import extract_live_candidates
            started=time.monotonic()
            before=json.dumps(state,sort_keys=True)
            ranked=rank_card_rewards(state,self.joint,board=self._board(state))
            if not ranked:
                return heuristic
            payload=ranked[0]["payload"]
            extract_live_candidates(state).identity_for(payload)
            if json.dumps(state,sort_keys=True)!=before:
                raise ValueError("Joint build value mutated native state")
            self.joint_usage["rewardRankings"]+=int(len(ranked)>1)
            metrics=dict(kind="card_reward",selected=payload,candidateCount=len(ranked),evaluated=ranked,
                jointValueSha256=binding["sha256"],jointValueConsumed=True,elapsedSeconds=time.monotonic()-started,
                forecastInvoked=False,forecastSource="Gradient-trained C9 capability/native return network; no fresh combat host",
                fallback=False,skipIsLegalCandidate=state["card_reward"].get("can_skip",True))
            self.engine.last_metrics=metrics
            self.engine.recorder.write("r51_joint_value_decision",dict(nativeDecisionId=state.get("decision_id"),metrics=metrics,
                firstActionOnly=True,mandatoryFreshNativeState=True))
            self._publish_usage()
            return payload

        def forecast_groups(self, states, deadline):
            # Retain the inherited [fight, elites..., boss] return contract,
            # but dispatch public Boss cases first across all compared plans.
            # The old scheduler could spend the entire shared deadline before
            # starting a single Boss. Every plan still has the same cases and
            # budgets; missing/censored outcomes remain explicit unknowns.
            from replay_probe_r1 import request_for
            from .probe_loadout import public_player_payload
            jobs, groups, keys = [], [], []
            for state, policy in states:
                act, config = state["run"]["act"], self.engine.config
                encounters = list(config.get("actsById", {}).get(state["run"].get("act_id"), config["acts"][str(act)]))
                boss = self.engine.current_public_boss(act)
                if boss:
                    encounters[2] = boss
                elites = config.get("eliteThreatsById", {}).get(state["run"].get("act_id"), config["eliteThreats"][str(act)])
                samples = [(0, encounters[0]), *[(i + 1, e) for i, e in enumerate(elites)], (2, encounters[2])]
                group, group_keys = [], []
                for sample, encounter in samples:
                    category = "boss" if encounter.endswith("_BOSS") else "elite" if encounter.endswith("_ELITE") else "fight"
                    seconds = float(self.budget.get(category + "Seconds", {"boss":45, "elite":25, "fight":8}[category]))
                    request = request_for(state, state["player"]["deck"], encounter, sample)
                    if "engineeringPublicPlayerSupport" not in request:
                        request, public, support = public_player_payload(state, request)
                        request.update(engineeringPublicPlayer=public, engineeringPublicPlayerSupport=support)
                    group.append(len(jobs))
                    group_keys.append(dict(encounterId=encounter, sampleSeed=request["seed"], potionPolicy=policy))
                    jobs.append((request, dict(potionPolicy=policy, budgetMilliseconds=int(seconds * 1000),
                        maxExpandedNodes=100000 if category=="boss" else 40000, beamWidth=48,
                        overallSecondsPerProbe=seconds+15, coordinator=True, preserveTerminalPlan=True,
                        propagateRemainingSearchBudget=True, replayReserveSeconds=5)))
                groups.append(group)
                keys.append(group_keys)
            columns = [len(groups[0])-1, *range(1,len(groups[0])-1), 0] if groups else []
            order = [group[column] for column in columns for group in groups]
            supported = [i for i in order if jobs[i][0].get("engineeringPublicPlayerSupport", {}).get("exactVisiblePreCombatFields")]
            values, metrics = self.scheduler.evaluate([jobs[i] for i in supported], deadline)
            mapped = dict(zip(supported, values))
            metrics.update(publicBossDispatchedFirst=True, unsupportedVisibleLoadoutsNotStarted=len(order)-len(supported),
                           requestedAllComparisons=len(jobs), missingMeansUnknown=True)
            self.forecast_case_keys = keys
            return [[mapped.get(i) for i in group] for group in groups], metrics

        def _publish_usage(self):
            self.joint_usage["predictions"] = self.joint.calls
            atomic_write(self.engine.output / "r51-joint-value-usage.json", self.joint_usage)

        def _board(self, state):
            act = state.get("run", {}).get("act")
            if act != self.joint_act:
                self.joint_board = self.joint_entered = None
                self.joint_act = act
            if state.get("state_type") == "map":
                self.joint_board = copy.deepcopy(state["map"])
                self.joint_entered = state["map"].get("current_position")
                return self.joint_board
            if self.joint_board is not None and self.joint_entered is not None:
                return remaining_board(self.joint_board, self.joint_entered)
            return None

        def decide(self, state, heuristic):
            kind = state.get("state_type")
            board = self._board(state)
            if kind not in ("map", "shop") or not isinstance(heuristic, dict):
                return super().decide(state, heuristic)
            initial = json.dumps(state, sort_keys=True)
            self.engine.observe_public_context(state)
            started = time.monotonic()
            if kind == "map":
                capability, metrics = [], {}
                if len(state["map"]["next_options"]) > 1:
                    groups, metrics = self.forecast_groups([(state, "Smart")], started + self.budget["decisionSeconds"])
                    probes, keys = groups[0], self.forecast_case_keys[0]
                    capability = completed_capabilities(probes, keys, maximum_hp=state["player"]["max_hp"])
                ranked = rank_routes(state, self.joint, capability_by_option={
                    option["index"]: capability for option in state["map"]["next_options"]})
                best = ranked[0]
                payload = dict(action="choose_map_node", index=best["index"])
                option = next(x for x in state["map"]["next_options"] if x["index"] == best["index"])
                self.joint_entered = {key: option[key] for key in ("col", "row", "type")}
                self.engine.observe_public_context(state, payload)
                self.joint_usage["routeRankings" if len(ranked) > 1 else "forcedRouteObservations"] += 1
                metrics.update(routeSelectionMode="r51_learned_joint_route_shop_build_value", evaluated=ranked,
                    capability=capability, publicInventoryScope="current public map; training-only future price distribution")
            else:
                if self.removal_modal_seen:
                    self.pending_native_removal = None
                    self.removal_modal_seen = False
                plans = enumerate_known_shop(state)
                ranked = rank_shop(state, plans, self.joint, board=board)
                shortlisted = combat_shortlist(ranked)
                groups, metrics = self.forecast_groups([(row["plan"]["state"], "Smart") for row in shortlisted],
                                                       started + self.budget["shopDecisionSeconds"])
                keys = self.forecast_case_keys
                if not all(k == keys[0] for k in keys):
                    raise ValueError("Joint shop forecasts have unmatched encounter/sample/potion keys")
                common = [i for i in range(len(groups[0])) if all(
                    group[i] is not None and group[i].get("terminal") and not group[i].get("censored")
                    and group[i].get("publicPlayerStateSupported") is not False for group in groups)]
                if common:
                    short_plans = [row["plan"] for row in shortlisted]
                    refined = rank_shop(state, short_plans, self.joint, board=board, capability_by_plan={
                        i: completed_capabilities(group, keys[i], common, state["player"]["max_hp"])
                        for i, group in enumerate(groups)})
                    best = refined[0]
                    selected_plan = best["plan"]
                else:
                    refined = []
                    selected_plan = ranked[0]["plan"]
                payload = native_action(selected_plan)
                self.pending_native_removal = (selected_plan["sequence"][0].get("removal")
                                               if selected_plan["sequence"] else None)
                if len({tuple(native_action(p).items()) for p in plans}) > 1:
                    self.joint_usage["shopRankings"] += 1
                def describe(row):
                    return dict(sourcePlanIndex=row["sourcePlanIndex"], spent=row["plan"]["spent"],
                        sequence=row["plan"]["sequence"], uncertainties=row["plan"]["uncertainties"],
                        preparation=row["plan"].get("preparation"),
                        prediction=row["prediction"], value=row["value"])
                metrics.update(shopSelectionMode="r51_joint_value_with_matched_observed_cases" if common else
                    "r51_joint_value_without_complete_common_cases", candidateCount=len(plans),
                    modelEvaluatedBeforeShortlist=len(ranked), retainedCandidateCount=len(shortlisted),
                    commonObservedCases=common, caseKeys=keys[0], fallback=False,
                    forecastComparisonIncomplete=len(common) < len(groups[0]),
                    unknownForecastsRetained=True, legacyPerCoinPenaltyApplied=False,
                    candidates=[describe(row) for row in ranked], refined=[describe(row) for row in refined])
            if payload.get("action") == "discard_potion":
                # Reuse the native occupied-slot/full-capacity contract.
                from shop_preparation_r14 import decide_resource
                decide_resource(self, state, payload)
            else:
                self.legal(state, payload)
            if json.dumps(state, sort_keys=True) != initial:
                raise ValueError("Joint resource ranking mutated native state")
            metrics.update(kind=kind, selected=payload, elapsedSeconds=time.monotonic() - started,
                           jointValueSha256=binding["sha256"], jointValueConsumed=True)
            self.last_metrics = metrics
            self.engine.recorder.write("r51_joint_value_decision", dict(nativeDecisionId=state.get("decision_id"),
                metrics=metrics, firstActionOnly=True, mandatoryFreshNativeState=True))
            self._publish_usage()
            return payload
    return ResourceChoice
