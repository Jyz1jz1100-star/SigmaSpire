"""Small, identity-checked joint-value MLP deployment without training packages."""
import hashlib
import json
import math
from pathlib import Path

from .codec import SCHEMA, PublicCodec

HEADS = ("native_policy_win_logit", "boss_survival_logit", "elite_survival_logit",
         "boss_hp_cost_fraction", "elite_hp_cost_fraction", "combat_turns_over_20")


def sigmoid(value):
    return 1 / (1 + math.exp(-max(-60., min(60., value))))


class JointValue:
    def __init__(self, path, expected_sha256):
        raw = Path(path).read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected_sha256:
            raise ValueError("Joint value model identity mismatch")
        self.model = json.loads(raw)
        if self.model["featureSchema"] != SCHEMA or tuple(self.model["headOrder"]) != HEADS:
            raise ValueError("Unsupported joint value schema")
        if not self.model.get("training", {}).get("optimizerSteps", 0):
            raise ValueError("Joint value weights have no gradient-training evidence")
        self.codec = PublicCodec(self.model["tokens"])
        self.calls = 0

    def predict(self, state, **context):
        vector = self.codec.encode(state, **context)
        if self.codec.names != self.model["featureNames"]:
            raise ValueError("Joint value feature identity mismatch")
        for index, layer in enumerate(self.model["layers"]):
            if len(layer["weight"]) != len(layer["bias"]) or any(len(row) != len(vector) for row in layer["weight"]):
                raise ValueError("Joint value dimension mismatch")
            vector = [math.fsum(w * x for w, x in zip(row, vector)) + bias
                      for row, bias in zip(layer["weight"], layer["bias"])]
            if index < len(self.model["layers"]) - 1:
                vector = [max(0., x) for x in vector]
        if len(vector) != len(HEADS) or not all(math.isfinite(x) for x in vector):
            raise ValueError("Nonfinite joint value prediction")
        self.calls += 1
        return dict(zip(HEADS, vector)) | {"nativePolicyWinProbability": sigmoid(vector[0]),
            "bossSurvivalProbability": sigmoid(vector[1]), "eliteSurvivalProbability": sigmoid(vector[2]),
            "causalOptimalActionProbability": False}
