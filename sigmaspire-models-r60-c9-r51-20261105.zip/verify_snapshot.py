"""Verify all packaged artifact identities without loading checkpoint code."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for name,entry in manifest['files'].items():
    raw=(root/name).read_bytes()
    assert len(raw)==entry['bytes'], name
    assert hashlib.sha256(raw).hexdigest()==entry['sha256'], name
    if name.endswith('.json'):json.loads(raw)
print('Verified',len(manifest['files']),'model, contract, source and license files')
